#!/usr/bin/env python
from cgi import *
# me
from dict import * 
from public import *  

POST = dict()
fs = FieldStorage()
for k in fs.keys():
    v =  fs[k].value
    POST[k] = v

public(POST)

if __name__=="__main__":
	pass
