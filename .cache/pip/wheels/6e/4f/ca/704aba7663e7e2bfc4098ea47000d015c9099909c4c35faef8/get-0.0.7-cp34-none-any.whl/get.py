#!/usr/bin/env python
__all__ = ["GET"]
import os
from dict import *
from query_string import *

GET = dict()
if "QUERY_STRING" in os.environ:
    QUERY_STRING = os.environ["QUERY_STRING"]
    qs = query_string(QUERY_STRING)
    for k in qs:
        v = qs[k]
        GET[k] = v

if __name__ == "__main__":
    print(GET)
